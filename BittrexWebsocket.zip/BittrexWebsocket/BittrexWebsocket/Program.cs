﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BittrexWebsocket
{
    internal class Program
    {
        private static BittrexWebsocket socket = new BittrexWebsocket();

        private static void Main(string[] args)
        {
            socket.OpenConnection();
            socket.Register("BTC-DOGE", (Callback));
            socket.Register("USDT-BTC", (Callback));
            socket.Unregister("BTC-DOGE");
            socket.Register("USDT-ETH", (Callback));
            Console.ReadLine();
            socket.CloseConnection();
        }

        private static void Callback(BittrexWebsocket.ExchangeState exchangeState)
        {
            Console.WriteLine(exchangeState.ToString());
        }
    }
}