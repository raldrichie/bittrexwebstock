﻿using Microsoft.AspNet.SignalR.Client;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace BittrexWebsocket
{
    public class BittrexWebsocket
    {
        private HubConnection hubConnection;
        private IHubProxy coreHubProxy;

        public bool queryExchangeStateInProgress = false;
        public bool verboseOutput = false;

        private Dictionary<string, Action<ExchangeState>> callbacks = new Dictionary<string, Action<ExchangeState>>();

        public BittrexWebsocket()
        {
            // Set up a connction to the Bittrex Hub
            hubConnection = new HubConnection("https://socket.bittrex.com");
            hubConnection.TraceLevel = TraceLevels.Events;
            hubConnection.TraceWriter = Console.Out;

            coreHubProxy = hubConnection.CreateHubProxy("CoreHub");

            // register a call back to the server so the client can be updated
            // on exchange changes for the markets registered
            coreHubProxy.On("updateExchangeState", marketJSon =>
                {
                    HandleUpdatedExchangeState(marketJSon);
                }
            );
        }

        public void OpenConnection()
        {
            if (!IsConnected())
            {
                hubConnection.Start().Wait();
            }
        }

        public void CloseConnection()
        {
            if (IsConnected())
            {
                hubConnection.Stop();
            }
        }

        public bool IsConnected()
        {
            return hubConnection.State == ConnectionState.Connected;
        }

        public void Register(string market, Action<ExchangeState> callback)
        {
            if (SubscribeExchangeState(market))
            {
                callbacks.Add(market, callback);
            }
        }

        public void Unregister(string market)
        {
            if (callbacks.ContainsKey(market))
            {
                callbacks.Remove(market);
            }
        }

        /**private static void Main(string[] args)
        {
            // Set up a connction to the Bittrex Hub
            hubConnection = new HubConnection("https://socket.bittrex.com");
            hubConnection.TraceLevel = TraceLevels.Events;
            hubConnection.TraceWriter = Console.Out;

            coreHubProxy = hubConnection.CreateHubProxy("CoreHub");

            // register a call back to the server so the client can be updated
            // on exchange changes for the markets registered
            coreHubProxy.On("updateExchangeState", marketJSon =>
            {
                HandleUpdatedExchangeState(marketJSon);
            }
            );

            // The sample holds a loop in the console to allow the user to
            // specify new markets to register for updates to while receiving
            // updates for already registered markets
            hubConnection.Start().ContinueWith(task =>
            {
                if (task.IsFaulted)
                {
                    Console.WriteLine("There was an error opening the connection:{0}",
                                      task.Exception.GetBaseException());
                }
                else
                {
                    Console.WriteLine("Connected");
                    bool breakLoop = false;

                    while (true)
                    {
                        string message = Console.ReadLine();

                        if (string.IsNullOrEmpty(message))
                        {
                            continue;
                        }
                        else
                        {
                            switch (message.ToLower())
                            {
                                case "quit":
                                    Console.WriteLine("quitting...");
                                    breakLoop = true;
                                    break;

                                case "verbose":
                                    verboseOutput = !verboseOutput;
                                    break;

                                default:
                                    // The marketName is case sensitive.  As all
                                    // are uppercase, forcing here
                                    queryExchangeState(message.ToUpper());
                                    break;
                            }
                        }

                        // user initiated Quit command
                        if (breakLoop) break;
                    }
                }
            }).Wait();

            // Loop was broken by 'quit' issued by user.  Stop the connection to
            // the hub
            hubConnection.Stop();
        }**/

        private bool SubscribeExchangeState(string marketName)
        {
            if (!IsConnected())
                return false;

            var task = coreHubProxy.Invoke("SubscribeToExchangeDeltas", marketName);
            task.Wait();
            return !task.IsFaulted && task.IsCompleted;

            /**
            // do not allow other queries until the current query is complete
            if (queryExchangeStateInProgress)
                return;

            queryExchangeStateInProgress = true;

            coreHubProxy.Invoke("SubscribeToExchangeDeltas", marketName).ContinueWith(task1 =>
            {
                if (task1.IsFaulted)
                {
                    Console.WriteLine("There was an error calling send: {0}", task1.Exception.GetBaseException());
                }
                else
                {
                    Console.WriteLine("Task Status: {0}", task1.Status.ToString());
                    Console.WriteLine("Result from Invoke {0}\n\t{1} registered for updates",
                        task1.Status.ToString(),
                        marketName);
                }
            });

            queryExchangeStateInProgress = false;**/
        }

        private void HandleUpdatedExchangeState(dynamic json)
        {
            // Deserialize the JSon broadcast from Server and display
            ExchangeState newExState = json.ToObject<ExchangeState>();
            if (callbacks.ContainsKey(newExState.MarketName))
            {
                callbacks[newExState.MarketName](newExState);
            }
            /**if (verboseOutput)
            {
                Console.WriteLine(newExState.ToString());
            }
            else
            {
                Console.WriteLine(String.Format("MarketName: {0}\tNounce: {1}",
                                        newExState.MarketName,
                                        newExState.Nounce));
            }**/
        }

        public class ExchangeState
        {
            [JsonProperty("MarketName")]
            public string MarketName { get; set; }

            [JsonProperty("Nounce")]
            public int Nounce { get; set; }

            [JsonProperty("Buys")]
            public List<TransactionInfo> Buys { get; set; }

            [JsonProperty("Sells")]
            public List<TransactionInfo> Sells { get; set; }

            [JsonProperty("Fills")]
            public List<OrderFillInfo> Fills { get; set; }

            public override string ToString()
            {
                StringBuilder output = new StringBuilder();
                output.AppendLine("MarketName: " + MarketName);
                output.AppendLine("Nounce: " + Nounce);

                output.AppendLine("Buys:");
                if (Buys.Count == 0)
                {
                    output.AppendLine("\tNo buys available...");
                }
                else
                {
                    foreach (TransactionInfo buy in Buys)
                    {
                        output.AppendLine("\tType: " + buy.Type);
                        output.AppendLine("\tRate: " + buy.Rate);
                        output.AppendLine("\tQuantity: " + buy.Quantity);
                    }
                }

                output.AppendLine("Sells:");
                if (Sells.Count == 0)
                {
                    output.AppendLine("\tNo sells available...");
                }
                else
                {
                    foreach (TransactionInfo sell in Sells)
                    {
                        output.AppendLine("\tType: " + sell.Type);
                        output.AppendLine("\tRate: " + sell.Rate);
                        output.AppendLine("\tQuantity: " + sell.Quantity);
                    }
                }

                output.AppendLine("Fills:");
                if (Fills.Count == 0)
                {
                    output.AppendLine("\tNo fills available...");
                }
                else
                {
                    foreach (OrderFillInfo fill in Fills)
                    {
                        output.AppendLine("\tOrderType: " + fill.OrderType);
                        output.AppendLine("\tRate: " + fill.Rate);
                        output.AppendLine("\tQuantity: " + fill.Quantity);
                        output.AppendLine("\tTimestamp: " + fill.TimeStamp);
                    }
                }

                return output.ToString();
            }
        }

        public class TransactionInfo
        {
            [JsonProperty("Type")]
            public int Type { get; set; }

            [JsonProperty("Rate")]
            public float Rate { get; set; }

            [JsonProperty("Quantity")]
            public float Quantity { get; set; }
        }

        public class OrderFillInfo
        {
            [JsonProperty("OrderType")]
            public string OrderType { get; set; }

            [JsonProperty("Rate")]
            public float Rate { get; set; }

            [JsonProperty("Quantity")]
            public float Quantity { get; set; }

            [JsonProperty("TimeStamp")]
            public DateTime TimeStamp { get; set; }
        }
    }
}